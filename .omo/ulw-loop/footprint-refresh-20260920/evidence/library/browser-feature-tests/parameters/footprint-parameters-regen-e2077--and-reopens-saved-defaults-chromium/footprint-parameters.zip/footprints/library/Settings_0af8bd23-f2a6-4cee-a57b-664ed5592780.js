module.exports={params:{side:"F",reversible:false,width:1,offset:[0,0]},body:p=>`(module "Settings" (layer ${p.side}.Cu) ${p.at} (pad 1 smd rect (at ${p.offset[0]} 0) (size ${p.width} 1) (layers ${p.side}.Cu)) ${p.reversible ? "(pad 2 smd rect (at 0 2) (size 1 1) (layers B.Cu))" : ""})`}
;module.exports = ((original) => {
    const params = {...original.params};
    const values = JSON.parse("{\"side\":\"B\",\"reversible\":true,\"width\":3}");
    for (const [key, value] of Object.entries(values)) {
      if (!Object.prototype.hasOwnProperty.call(params, key)) {
        throw new Error('Unknown footprint parameter: ' + key);
      }
      const spec = params[key];
      const expanded = spec && typeof spec === 'object' && !Array.isArray(spec)
        && Object.keys(spec).length === 2 && 'type' in spec && 'value' in spec;
      Object.defineProperty(params, key, {
        value: expanded ? {...spec, value}
          : spec === undefined || spec === null ? {type: 'net', value} : value,
        enumerable: true, writable: true, configurable: true
      });
    }
    return {...original, params};
  })(module.exports);
