const frames = require('./frames')
const footprints = require('../footprint-tools')

// Keep model-local transforms intact and locate them from the emitted KiCad footprint.
exports.collect = (source, item, boardFrame, thickness, footprintKey) => {
    const models = []
    for (const target of footprints.inspect(source).targets) {
        const info = footprints.inspect(source, target)
        if (!info.models.length) { continue }
        const [x,y,rotation] = info.at
        const bottom = info.side === 'B'
        const placement = frames.local([x,-y,bottom ? 0 : thickness], rotation, bottom ? 180 : 0)
        const frame = frames.multiply(frames.inverse(item.matrix), frames.multiply(boardFrame, placement))
        models.push(...info.models.map(model => ({...model, frame, footprintKey, footprintReference: target.reference})))
    }
    return models
}
